#include "SelectLayer.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "MainScene.h"

#include "Slide.h"
#include "ClickMe.h"

using namespace cocostudio::timeline;
bool SelectLayer::init()
{
	if (!Layer::init())
	{
		return false;
	}

	Node* rootNode = CSLoader::createNode("SelectScene.csb");
	this->addChild(rootNode);

	Node *selectContainer = rootNode->getChildByName("selectContainer"),
		*panel1 = selectContainer->getChildByName("Panel_1"),
		*panel2 = selectContainer->getChildByName("Panel_2");

	Button *slideButton = static_cast<Button*>(panel1->getChildByName("slide"));
	slideButton->addClickEventListener(CC_CALLBACK_1(SelectLayer::clickButton, this));

	Button *clickMeButton = static_cast<Button*>(panel1->getChildByName("clickMe"));
	clickMeButton->addClickEventListener(CC_CALLBACK_1(SelectLayer::clickButton, this));

	return true;
}
void SelectLayer::clickButton(Ref *ref){
	std::string name = (static_cast<Node*> (ref))->getName();
	if (name == "slide")
		MainScene::Instance()->gameLayer = Slide::create();
	else{
		if (name == "clickMe")
			MainScene::Instance()->gameLayer = ClickMe::create();

	}
	MainScene::Instance()->addChild(MainScene::Instance()->gameLayer);
	this->setVisible(false);
}