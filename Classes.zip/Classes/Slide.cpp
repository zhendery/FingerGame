#include "Slide.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include <math.h>
#include "MainScene.h"

using namespace cocostudio::timeline;


bool Slide::init()
{
	if (!Layer::init())
	{
		return false;
	}

	auto listen = EventListenerTouchAllAtOnce::create();
	//listen->onTouchesBegan = CC_CALLBACK_2(Slide::onTouchesBegan, this);
	listen->onTouchesEnded = CC_CALLBACK_2(Slide::onTouchesEnded, this);
	Director::getInstance()->getEventDispatcher()->addEventListenerWithSceneGraphPriority(listen, this);

	Node* rootNode = CSLoader::createNode("Slide.csb");
	this->addChild(rootNode);

	//Node *
	text = static_cast<Text*>(rootNode->getChildByName("text"));
	arrows[0] = static_cast<Sprite*>(rootNode->getChildByName("arrowLeft"));
	arrows[1] = static_cast<Sprite*>(rootNode->getChildByName("arrowRight"));

	setDir();

	first = true;
	return true;
}

void Slide::onTouchesEnded(const std::vector<Touch*>& touches, cocos2d::Event  *event){
	Vec2 go = touches[0]->getLocation() - touches[0]->getStartLocation();
	if (touches[0]->getStartLocation().x<Director::getInstance()->getWinSize().width/2)
	if (abs(go.x) > abs(go.y)){
		//����
		if (go.x > 0)
			slide(2);//��
		else
			slide(0);//��
	}
	else{
		if (go.y > 0)
			slide(1);//��
		else
			slide(3);//��
	}
}
void Slide::slide(int dir){
	if (first){
		if (dir == dirs[0]){//�ɹ�ƥ��
			log("trueee1");
			first = false;
		} else{
			log("falsesss1");//����
		}
	}
	else{
		if (dir == dirs[1]){//�ɹ�ƥ��
			log("trueee2");
			setDir();
			first = true;
		}
		else{
			log("falsesss2");//����
		}
	}
}

void Slide::setDir(){
	for (int i = 0; i < 2; ++i){
		int dir = random(4);

		Color3B color = colors[(int) random(9)];
		this->arrows[i]->setColor(color);
		this->arrows[i]->setRotation(90 * dir);
		this->dirs[i] = dir;
	}
}