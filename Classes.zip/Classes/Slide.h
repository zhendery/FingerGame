#ifndef __SLIDE_H__
#define __SLIDE_H__

#include "cocos2d.h"
#include "ui/CocosGUI.h"

#define random(x) (rand()%x)

USING_NS_CC;
using namespace ui;

class Slide : public Layer
{
public:
	CREATE_FUNC(Slide)
		bool init();

private:
	Sprite *arrows[2];
	int dirs[2];
	Text *text;

	void onTouchesEnded(const std::vector<Touch*>& touches, cocos2d::Event  *event);
	bool first;
	void slide(int dir);

	void setDir();
};

#endif // __SLIDE_H__
